# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_followup
from . import account_followup_report
from . import res_partner
from . import chart_template
from . import account_move_line
