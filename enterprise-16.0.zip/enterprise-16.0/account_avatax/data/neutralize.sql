-- disable AvaTax
UPDATE account_fiscal_position
   SET is_avatax = false;
