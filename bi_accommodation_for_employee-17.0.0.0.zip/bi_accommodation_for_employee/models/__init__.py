# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import bi_hotel
from . import bi_location
from . import employee_accommodation

