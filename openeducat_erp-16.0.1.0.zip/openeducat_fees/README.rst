This module provide feature of fees collection & other finance operations.
